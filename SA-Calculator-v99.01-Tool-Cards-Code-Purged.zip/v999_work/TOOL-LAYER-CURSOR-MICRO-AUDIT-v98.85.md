# v98.85 Tool Layer and Cursor Audit

## Source recording findings
The 58.8-second screen recording shows Other Calculator launcher, GST, Loan, Saving, Unit Converter and Currency Converter. Unit Converter opens a second category bottom-sheet layer that is clipped; its category chips already provide inline selection. The shared keypad shows swap glyphs in converter contexts. Currency converter shows a live amount field, selectors and a swap-style keypad action. Across Loan/Saving/Unit/Currency/Unit screens, dark field surfaces and a black keypad backing contrast with the light page background. The recording shows caret/focus indicators but does not prove all pointer positions; code inspection confirms numeric tool entry was append/delete-at-end only.

## Changes
- White tool surfaces for Tools launcher, supported finance/conversion tools, shared keypad and editable fields.
- Inline category chooser; hidden legacy category picker/back layer disabled.
- Unit swap kept as one keypad action; duplicate visible unit swap control hidden.
- Currency remains live conversion; redundant keypad swap action replaced by Calculate/refresh.
- Tap position maps to a raw numeric caret index; keypad digit/decimal inserts at that position and DEL removes the preceding digit.
- Caret is rendered inline within the editable text span and is retained through numeric formatting.

## Validation boundaries
The supplied recording is a UI observation, not a complete functional test suite. Local source tests, syntax checks, bundle synchronization, YAML parsing and archive integrity are performed for this release. Actual Android touch testing, device rotation, accessibility review, network provider behavior and remote GitHub Actions execution remain external validation items.
