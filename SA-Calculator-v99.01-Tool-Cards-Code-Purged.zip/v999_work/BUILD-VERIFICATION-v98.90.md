# Build verification — v98.90

## Automated checks actually executed

- `npm test`: **139 passed, 0 failed**.
- `node --check assets/js/app.js`: passed.
- `node --check assets/js/localization.js`: passed.
- `node scripts/prepare-android-web.mjs`: passed; 13 required Android web assets verified.
- YAML parsing: **14 workflow copies parsed**; all copies byte-identical.
- Release test entry paths: **25 present**, 0 missing.
- Workflow source/test required paths: **39 present**, 0 missing.
- Root-to-`www/` parity: **8/8 assets byte-identical**.
- ZIP integrity: passed; 190 entries.
- Release identity: `1.99.06-v98.92`, Android versionCode `1099111`.
- Service-worker cache: `sa-calculator-v98-92-gst-rate-position-placeholder-preset-v9892`.

## Not performed / not claimed

- No physical Android device test for touch, caret position, long-value scrolling, rotation, safe areas, or frame-rate/performance.
- No remote GitHub Actions run was triggered.
- No signed or debug APK was built in this environment.
- Chromium screenshot rendering was attempted but timed out; therefore no browser screenshot is claimed as visually verified.

Automated source checks passed. These results do not guarantee zero defects or lag-free behavior on every Android device.
