# SA Calculator v98.85

- GST screen and its active numeric keypad now use a clean white/light surface even if the app-wide theme is dark.
- Removed the remaining GST input outlines and compacted GST amount/rate controls.
- Restored visible GST rate entry and kept both mode and state controls clear of the keypad overlay.
- Existing GST calculation logic and shared keypad action handlers are preserved.
