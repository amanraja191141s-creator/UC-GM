# SA Calculator v98.92 — GST Screenshot-Matched Audit

## Screenshot target
- First red-marked line: `GST Rate(%)` at the upper-left of the rate-field content area, horizontally aligned beside the percent icon.
- Second red-marked line: `Add rate` input followed by `5%` and `18%` on the same row.
- Preserve the Original Amount card, GST mode selector, Same State / Different State controls, shared keypad and result card.

## Source findings corrected
1. The GST rate card accumulated multiple historical grid/flex overrides. The final rate label and entry row could inherit conflicting positioning. v98.92 uses a deterministic positioned field: label anchored to the top; entry row anchored to the bottom; both remain in the same rate card beside the icon.
2. Placeholder pseudo-elements existed on both the field and its nested `.input-text`, allowing duplicate placeholder painting. v98.92 suppresses nested placeholder pseudo-elements and leaves one field-level placeholder.
3. Same State / Different State visibility was only refreshed after valid input in the calculation path. v98.92 applies row visibility and `aria-hidden` state before validation, so the selected breakdown stays correct even when fields are incomplete.
4. Manually typing or deleting a GST rate could leave the 5% / 18% preset highlight stale. v98.92 synchronizes active class and `aria-pressed` with the typed value.
5. When focus moved between GST fields, parent and child empty-state classes could drift. v98.92 synchronizes both.

## Expected GST behaviour
- Same State: SGST and CGST each show half the selected GST rate and half the tax amount; IGST is hidden.
- Different State: IGST shows the full selected GST rate and full tax amount; SGST and CGST are hidden.
- With GST: entered amount is taxable value; GST is added.
- Without GST: entered amount is inclusive gross; tax is extracted.
- 5% and 18% buttons populate the rate input and place the custom caret before the `%` suffix. Manual entry updates the preset highlight only when it exactly matches 5 or 18.

## Verification boundary
Automated source regression suite and package checks pass. No physical Android device session, APK build/signing, remote GitHub Actions run, or successful browser screenshot render is claimed. Device-specific visual alignment, touch/caret feel, safe-area handling and performance still need on-device confirmation.
