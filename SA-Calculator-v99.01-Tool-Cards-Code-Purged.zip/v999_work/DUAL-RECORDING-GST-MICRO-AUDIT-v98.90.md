# Dual recording micro audit — v98.90

## Evidence from both supplied recordings

**Recording 2026-11-24 15:03:49 (25.51 s):** GST Calculator shows the Amount entry progressing to a long formatted number. At approximately 5.1–7.7 s, a floating Android text-selection/handle overlay appears over the amount field. At approximately 15.3 s, the rate validation toast appears. At approximately 17.9 s, the amount is cleared while the Different State selection remains. The result card is visible at approximately 12.8 s.

**Recording 2026-11-24 15:04:33 (23.39 s):** The amount placeholder remains visibly printed after digits are entered (2.3–7.0 s and 11.7–14.0 s), overlapping the amount. The rate field shows `Add rate` in a separate left-side position while `GST Rate(%)` is displaced to the right; the rate value is also not consistently positioned. At approximately 16.4 s, the result panel is dark navy against the light form. The final transition at 18.7 s shows a dark Tools screen; this is a separate app screen and was not globally recolored.

## Source-level causes
- GST styling accumulated multiple contradictory appended rules. Earlier blocks used `display:contents`, 2-column and 3-column grids, and competing row heights.
- Rate quick buttons are nested inside `.gst-rate-entry-row`, but older layout rules positioned `.gst-quick-rates` as if it were a direct child of `.gst-rate-card`.
- Placeholder state was inferred from different DOM shapes (`:empty`, `:has(cursor:only-child)`, and `.is-empty`) across revisions. The latest patch makes the field-level `.is-empty` class authoritative and suppresses all legacy pseudo placeholders.
- Native WebView text selection/callout could appear over custom virtual-keypad inputs; GST custom fields now suppress native selection while preserving app-managed caret placement.
- Result surface had conflicting theme rules; final scoped rule enforces light surface and visible auto-height rows.

## Scope and limits
- GST-specific changes only; Tools home screen dark appearance in the second recording is not treated as a GST defect and was not globally changed.
- The recordings show GST UI only. They do not establish the current behavior of every other calculator tool.
- Local source tests and Android web preparation can be run here; no physical Android device or remote GitHub Actions environment is available for this verification.
