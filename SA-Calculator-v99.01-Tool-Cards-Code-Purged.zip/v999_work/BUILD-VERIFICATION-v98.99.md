# SA Calculator v98.99 — Build Verification

## Release identity
- App version: `1.99.13-v98.99`
- Android versionCode: `1099119`
- Service worker cache: `sa-calculator-v98-99-all-tool-cards-flat-v9899`

## Automated checks completed
- `npm test`: **177 passed, 0 failed**
- `npm run build:web`: passed; 13 required web assets verified
- JavaScript syntax checks: passed for app.js, localization.js, theme-bootstrap.js, server.js and service-worker.js
- YAML parsing: 26 project YAML/YML files parsed successfully
- Root/www parity: 6/6 authoritative assets byte-identical
- New all-tool-card regression coverage: 5 tests
- ZIP integrity: checked after packaging

## Scope of visual change
Card chrome (background, border, rounded corners and shadow) is removed from the tool form, field-wrapper and result-card families, and from Tools launcher tiles. The tool grid, icons, labels, input controls, caret/focus behavior, calculation handlers, result content, keypad, dialogs, navigation and Settings surfaces are retained.

## Not claimed as completed
No physical Android device screenshot comparison, touch/scroll test, APK build/install/signing, or remote GitHub Actions run was performed in this environment. Actual device appearance can vary by Android WebView and screen density; verify on the target phone before treating the visual review as final.
