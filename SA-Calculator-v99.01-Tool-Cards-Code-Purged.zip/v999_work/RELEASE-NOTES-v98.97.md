# SA Calculator v98.98 — GST single-placeholder rendering

- Prevented duplicate GST amount/rate placeholder rendering by assigning placeholder ownership to the inline value span only.
- Preserved shared keypad, caret, field sizing and per-tool card geometry.
- Added dedicated GST placeholder regression tests.
- App version: `1.99.12-v98.98`; Android versionCode: `1099118`.
