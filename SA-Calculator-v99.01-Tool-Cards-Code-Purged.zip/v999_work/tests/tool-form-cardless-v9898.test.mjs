import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p,'utf8');
test('v98.98 flattens redundant tool form wrappers only',()=>{
 const css=read('assets/css/tool-reference-ui.css');
 assert.ok(css.includes('v98.98 — flatten outer tool form cards'));
 assert.ok(css.includes('.tool-input-group:not(.settings-card)'));
 assert.ok(css.includes('.tool-form-content'));
 assert.ok(css.includes(':not(#screen-tools):not(#screen-settings)'));
});
test('tools catalogue and interactive fields remain present',()=>{
 const html=read('index.html');
 const css=read('assets/css/tool-reference-ui.css');
 assert.ok(html.includes('class="tool-launch-item"'));
 assert.ok(html.includes('class="input-val-box'));
 assert.ok(css.includes('.input-val-box'));
});
test('source and web stylesheet stay identical',()=>assert.equal(read('assets/css/tool-reference-ui.css'),read('www/assets/css/tool-reference-ui.css')));
test('release identity and cache namespace are synchronized',()=>{
 const pkg=JSON.parse(read('package.json'));
 assert.equal(pkg.version,'1.99.15-v99.01');
 assert.equal(pkg.androidVersionCode,1099130);
 assert.ok(read('service-worker.js').includes('sa-calculator-v99-01-card-css-purged-v9901'));
 assert.ok(read('index.html').includes('1.99.15-v99.01'));
});
