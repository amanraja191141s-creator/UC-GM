import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const html = read('index.html');
const js = read('assets/js/app.js');
const css = read('assets/css/tool-reference-ui.css');
const pkg = JSON.parse(read('package.json'));

const tools = [
  'currencies','units','discount','percent','salestax','agecalc','bodymetrics','date',
  'fuelcost','fuelefficiency','gradeavg','hex','loan','salary','savings','sip','tip','unitprice','worldtime'
];

test('all 19 calculator tools remain registered with a matching screen', () => {
  for (const tool of tools) {
    assert.match(html, new RegExp(`id="screen-${tool}"`), `missing screen-${tool}`);
  }
});

test('shared tool field semantics initialize before keypad interaction and after restore', () => {
  assert.match(js, /function initSharedToolFieldSemantics\(\)/);
  assert.match(js, /initSharedToolFieldSemantics\(\);\s*initDrawer\(\);/);
  assert.match(js, /restorePreviousInputs\(\);\s*initSharedToolFieldSemantics\(\);/);
  assert.match(js, /field\.setAttribute\('role', 'textbox'\)/);
  assert.match(js, /field\.setAttribute\('inputmode', 'decimal'\)/);
  assert.match(js, /field\.classList\.toggle\('is-empty', empty\)/);
});

test('all tools use the shared docked keypad and a single app-managed caret', () => {
  assert.match(js, /function openToolKeypad\(inputElem\)/);
  assert.match(js, /function renderToolInputValue\(target, displayValue, caretIndex\)/);
  assert.match(js, /function setActiveInput\(elem\)/);
  assert.match(js, /el\.querySelectorAll\('\.input-text > \.input-cursor'\)/);
  assert.match(css, /\.input-val-box\[data-tool-field="true"\] \.input-cursor/);
});

test('empty placeholders are rendered from one field-level source for every tool', () => {
  assert.match(css, /\.input-val-box\[data-tool-field="true"\]\.is-empty::after/);
  assert.match(css, /content:attr\(data-placeholder\)/);
  assert.match(js, /field\.classList\.toggle\('is-empty', empty\)/);
});

test('custom numeric fields suppress Android native selection overlays', () => {
  assert.match(css, /-webkit-touch-callout:none/);
  assert.match(css, /-webkit-user-select:none/);
  assert.match(css, /touch-action:manipulation/);
});

test('release identity is synchronized for v98.93', () => {
  assert.equal(pkg.version, '1.99.15-v99.01');
  assert.equal(pkg.androidVersionCode, 1099130);
  assert.match(html, /1\.99\.15-v99\.01/);
  assert.match(read('manifest.webmanifest'), /1\.99\.15-v99\.01/);
  assert.match(read('service-worker.js'), /sa-calculator-v99-01-card-css-purged-v9901/);
});
