import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');

test('GST inputs contain one caret host, not a duplicate sibling caret', () => {
  const html = read('index.html');
  const amount = html.match(/id="tax-orig"[\s\S]*?<\/div><\/label>/)?.[0] ?? '';
  const rate = html.match(/<div class="gst-rate-entry-row">[\s\S]*?id="tax-rate"[\s\S]*?data-gst-rate="18"[\s\S]*?<\/div>/)?.[0] ?? '';
  assert.match(amount, /<span class="input-text is-empty" data-placeholder="Enter amount"><\/span>/);
  assert.doesNotMatch(amount, /<span class="input-cursor"><\/span>/);
  assert.match(rate, /<span class="input-text is-empty" data-placeholder="Add rate"><\/span>/);
  assert.doesNotMatch(rate, /<span class="input-cursor"><\/span>/);
});

test('GST layout forces amount, mode, rate and state into normal document flow', () => {
  const css = read('assets/css/tool-reference-ui.css');
  const finalLayer = css.slice(css.lastIndexOf('v98.86 — GST action-time layout'));
  assert.match(finalLayer, /\.gst-mode-row,[\s\S]*?position:static !important/);
  assert.match(finalLayer, /\.gst-place-row[\s\S]*?position:static !important/);
  assert.match(finalLayer, /\.gst-rate-group[\s\S]*?grid-template-columns:56px minmax\(0,1fr\) auto/);
  assert.match(finalLayer, /\.gst-quick-rates[\s\S]*?grid-column:3 !important/);
});

test('GST result card can expand and scroll instead of clipping lower rows', () => {
  const css = read('assets/css/tool-reference-ui.css');
  const finalLayer = css.slice(css.lastIndexOf('v98.86 — GST action-time layout'));
  assert.match(finalLayer, /\.tool-result-content[\s\S]*?max-height:none !important/);
  assert.match(finalLayer, /\.tool-result-content[\s\S]*?overflow:visible !important/);
  assert.match(finalLayer, /\.gst-reference-layout[\s\S]*?overflow-y:auto !important/);
});

test('GST caret is rendered once inside the input text and raw/display mapping handles separators', () => {
  const js = read('assets/js/app.js');
  assert.match(js, /function renderToolInputValue\([\s\S]*?textSpan\.replaceChildren\([\s\S]*?cursor[\s\S]*?\);/);
  assert.match(js, /function setActiveInput\([\s\S]*?renderToolInputValue\(elem, currentDisplay, Number\(elem\.dataset\.caretIndex\)\)/);
  assert.match(js, /const rawValue = value\.replace\(\/\[,\\s₹\$%\]\/g, ''\)/);
  assert.match(js, /if \(!\/\[,\\s₹\$%\]\/\.test\(value\[displayIndex\]\)\) rawSeen\+\+/);
});

test('release identity and Android web copies match v98.86', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.version, '1.99.15-v99.01');
  assert.equal(pkg.androidVersionCode, 1099130);
  for (const rel of ['index.html','assets/js/app.js','assets/css/tool-reference-ui.css','service-worker.js','manifest.webmanifest']) {
    assert.equal(read(rel), read(path.join('www', rel)), `${rel} differs from www copy`);
  }
});
