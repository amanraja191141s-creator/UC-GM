import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
test('v98.87 GST measured geometry uses compact normal-flow rows and bounded fields',()=>{
 const css=read('assets/css/tool-reference-ui.css');
 const layer=css.slice(css.lastIndexOf('v98.87 — screenshot-measured GST geometry'));
 assert.match(layer,/height:98px !important/);
 assert.match(layer,/grid-template-columns:55px minmax\(0,1fr\) auto !important/);
 assert.match(layer,/justify-content:flex-end !important/);
 assert.match(layer,/flex:0 0 28px !important/);
 assert.match(layer,/overflow:visible !important/);
});
test('v98.87 mode and state controls have independent measured widths',()=>{
 const css=read('assets/css/tool-reference-ui.css');
 const layer=css.slice(css.lastIndexOf('v98.87 — screenshot-measured GST geometry'));
 for(const rule of ['.gst-mode-row .gst-choice:first-child { width:92px','.gst-mode-row .gst-choice:last-child { width:112px','.gst-place-row .gst-choice:first-child { width:107px','.gst-place-row .gst-choice:last-child { width:124px']) assert.ok(layer.includes(rule),rule);
});
test('v98.87 keeps GST responsive at narrow and short viewport sizes',()=>{
 const css=read('assets/css/tool-reference-ui.css');
 const layer=css.slice(css.lastIndexOf('v98.87 — screenshot-measured GST geometry'));
 assert.match(layer,/@media \(max-width:360px\)/);
 assert.match(layer,/@media \(max-height:620px\)/);
});
test('v98.87 release identity and cache namespace are synchronized',()=>{
 const pkg=JSON.parse(read('package.json'));
 assert.equal(pkg.version,'1.99.15-v99.01');
 assert.equal(pkg.androidVersionCode,1099130);
 assert.match(read('service-worker.js'),/sa-calculator-v99-01-card-css-purged-v9901/);
});
