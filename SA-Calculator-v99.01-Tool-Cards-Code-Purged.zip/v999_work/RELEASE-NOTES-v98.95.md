# SA Calculator v98.95 — Release notes

- Reduced every previously standardized calculator-tool card from 114px to 64px (exactly 50px shorter).
- Kept maximum width at 430px and responsive width on narrower devices.
- Preserved tool-specific card layout, cursor/input logic, and contained scrolling for dense content.
- App version: `1.99.09-v98.95`
- Android versionCode: `1099115`
- Service worker cache: `sa-calculator-v98-95-all-tool-card-geometry-430x64-v9895`
