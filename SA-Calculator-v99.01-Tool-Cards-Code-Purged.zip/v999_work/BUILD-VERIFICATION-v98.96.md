# SA Calculator v98.96 — Build verification

## Automated results
- Release regression suite: **164 passed, 0 failed** (`npm test`).
- JavaScript syntax: `assets/js/app.js`, `assets/js/localization.js`, `assets/js/theme-bootstrap.js`, `server.js`, `service-worker.js`, and both Android preparation scripts pass `node --check`.
- Android web bundle: `npm run build:web` passed; 13 required assets verified and authoritative CSS copied byte-for-byte.
- Source/Android web parity: `app.js`, `app.css`, `tool-reference-ui.css`, `localization.js`, `theme-bootstrap.js`, `index.html`, `manifest.webmanifest`, and `service-worker.js` verified byte-identical.
- HTML IDs: checked for duplicates.
- Workflow: exact source version, Android versionCode, required release files and explicit test paths checked.
- Project YAML files: syntax parsed and workflow mirrors checked for identical content.
- ZIP packaging: integrity test passed after archive creation.

## Release identity
- App version: `1.99.10-v98.96`
- Android versionCode: `1099116`
- Service worker cache: `sa-calculator-v98-96-content-first-tool-card-geometry-v9896`

## Not performed
No physical Android screenshot/pixel measurement, touch-scroll test, APK compilation/signing/installation, or remote GitHub Actions execution was performed in this environment. No claim of zero lag or zero bugs on every device is made.
