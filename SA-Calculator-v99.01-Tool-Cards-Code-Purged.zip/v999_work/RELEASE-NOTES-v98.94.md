# SA Calculator v98.94 — Release notes

## All-tool card geometry

- Standardized calculator-tool card boundaries to a 430 CSS px maximum width and an exact 114 CSS px height.
- Added narrow-screen width fallback so cards never force horizontal viewport overflow.
- Added contained vertical scrolling for dense form/result cards so their full contents remain accessible within the fixed boundary.
- Applied the contract to 19 tool screens and dynamic date-event, world-clock and GPA rows.
- Preserved specialized layouts: GST rate grid, Percentage input rows, Age wrapper, currency fields, Discount rows and Hex base rows.
- Kept tool launcher tiles, modal dialogs, keypad buttons, settings cards and decorative wrappers outside this tool-content-card rule.

## Release identity

- App version: `1.99.08-v98.94`
- Android versionCode: `1099114`
- Service worker cache: `sa-calculator-v98-94-all-tool-card-geometry-430x114-v9894`

## Validation

- 161 automated tests passed, 0 failed.
- 21 project YAML files parsed and matched byte-for-byte; standalone v98.94 Android YAML included.
- 13 Android web assets verified by the project build preparation script.
- 8/8 root and `www` web assets matched.
- ZIP integrity check passed.

Physical-device testing, pixel-perfect screenshot comparison, APK build/signing and remote GitHub Actions execution remain unverified.
